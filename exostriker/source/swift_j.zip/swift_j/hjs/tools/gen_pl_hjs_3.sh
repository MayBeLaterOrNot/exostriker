gen_pl_hjs <<!
1   !   AU & Years
1   !   Invariable plane
3   !  # of bodies in the system
2.97704   !
1.56918   !
1.26 ! Masses of bodies in solar masses
-1 1 0 ! Orbit 1 : Body #2 orbiting Body #1
0.0656 0.0216 90. 0. -18.0 0.0 ! Small orbit
-1 -1 1 ! Orbit 2 : Body #3 orbiting Body #1 + Body #2
1.47 0.507 20. -100. 153. 0.0 ! Large orbit
plhjs_3.in
!
exit
